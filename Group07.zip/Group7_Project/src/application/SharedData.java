package application;

public class SharedData {

	public static String ID;
	public static String password;

}
