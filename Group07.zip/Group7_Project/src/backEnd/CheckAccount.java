package backEnd;

public interface CheckAccount {
	
	boolean checkID(String ID);
	
	boolean checkPassword(String password);

}
